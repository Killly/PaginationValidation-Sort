<?php

$login = "root";
$pass = "root";

$dsn = 'mysql:host=localhost;dbname=basefortest';
$pdo = new PDO($dsn, $login, $pass);




?>